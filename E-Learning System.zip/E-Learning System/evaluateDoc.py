import nltk

from nltk import sent_tokenize, word_tokenize

from nltk.corpus import PlaintextCorpusReader

corpus_root = "./UCSC Sinhala Tagged Corpus V1"
docs = PlaintextCorpusReader(corpus_root, '.*')

fields = docs.fileids()
totaldocs = len(fields)

writePath = "./UCSC Sinhala Tagged Corpus V1/Tagged Words.txt"
write_file = open(writePath, 'a', encoding="utf16")


def evaluateDocs():
    POStag_list = {}
    readPath = "./UCSC Sinhala Tagged Corpus V1/Tagged Words.txt"
    # print(readPath)
    read_file = open(readPath, 'r', encoding="utf16")
    file = read_file.read()

    words = word_tokenize(file)
    for word in words:
        # print(word)
        items = word.split("_")
        # print(items)
        if len(items) == 2:
            if items[0] != '' and items[1] != '':
                POStag_list[items[0]] = items[1]

    print(POStag_list)
    return POStag_list
