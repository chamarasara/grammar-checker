import nltk

from nltk import sent_tokenize, word_tokenize

from nltk.corpus import PlaintextCorpusReader
from evaluateDoc import evaluateDocs
from POSTagging import FindPosTag


# evaluateDocs()
FindPosTag("මම සෙල්ලම් කරනවා")
