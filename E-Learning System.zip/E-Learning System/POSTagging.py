import nltk
from nltk import word_tokenize
from evaluateDoc import evaluateDocs


def FindPosTag(sent):
    print(sent)
    PosTagList = evaluateDocs()

    words = word_tokenize(sent)
    print(words)

    for word in words:
        PosTag = PosTagList[word]
        print(word + " - " + PosTag)

